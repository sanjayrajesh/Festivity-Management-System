<!DOCTYPE html>
<html>
  <head>
    <meta charset='utf-8' />
    <title>FMS - News</title>
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <link href='css/style.css' rel='stylesheet' />
  </head>
  <body>
    <input id="toggle" type="checkbox" style="position: absolute; z-index: 100;">
    <label class="toggle-container" for="toggle">
      <span class="button button-toggle"></span>
    </label>
    <nav class="nav" style="position: absolute; z-index: 100;">
      <a class="nav-item" href="http://amrita.edu">amirta.edu</a>
      <a class="nav-item" href="index.html">Map</a>
      <a class="nav-item" href="https://www.amritapuri.org/">amritapuri.net</a>
      <a class="nav-item" href="https://www.facebook.com/MataAmritanandamayi">Facebook</a>
      <a class="nav-item" href="https://twitter.com/Amritanandamayi">Twitter</a>
      <a class="nav-item" href="https://www.instagram.com/Amritanandamayi/">Instagram</a>
      <a class="nav-item" href="https://www.youtube.com/user/amma">Youtube</a>
    </nav>
    <br><br><br>
<?php
    $dbServerName = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "fmsevents";

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = mysqli_query($conn, "SELECT title, time, descrip FROM NEWS ORDER BY time DESC");

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    echo "<div class=\"listItem\"><h1>".$row["title"]."</h1><p class=\"desc\">".$row["descrip"]."</p><small>".$row["time"]."</small><br><br></div>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
mysqli_close($conn);
?>