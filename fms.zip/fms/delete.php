<?php

    $dbServerName = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "fmsevents";
    
    $db = $_GET["db"];
    $event = $_GET["event"];
    $time = $_GET["time"];
    
    // create connection
    $conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);
    
    // check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $result = mysqli_query($conn, "DELETE FROM $db WHERE event = \"$event\" AND time = \"$time\"");
    $conn->close();
    header("Location:admin.php?db=$db&update=$event");
?>