<?php

    $dbServerName = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "fmsevents";
    
    $db = $_POST["db"];
    $event = $_POST["event"];
    $time = $_POST["time"];
    
    // create connection
    $conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);
    
    // check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $result = mysqli_query($conn, "INSERT INTO $db VALUES(\"$event\",\"$time\");");
    $conn->close();
    header("Location:admin.php?db=$db&update=$event");
?>