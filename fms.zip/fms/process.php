<?php
    session_start();
    $uname = $_POST["uname"];
    $pass = $_POST["pass"];
    
$dbServerName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "fmsevents";

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = mysqli_query($conn, "SELECT * FROM USERS where username like \"$uname\" and password like \"$pass\";");
if ($result->num_rows > 0) {
    $_SESSION["uname"] = $uname;
mysqli_close($conn);
    header("Location:admin.php");
} else {
mysqli_close($conn);
    header("Location:login.php?user=notValid");
}

?>