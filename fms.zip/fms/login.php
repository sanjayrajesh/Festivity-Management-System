<!DOCTYPE html>
<html>
  <head>
    <meta charset='utf-8' />
    <title>FMS</title>
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.css' rel='stylesheet' />
    <link href='css/style.css' rel='stylesheet' />
    <style>
        * {
box-sizing: border-box;
}

*:focus {
	outline: none;
}
body {
font-family: Arial;
background-color: lightsteelblue;
padding: 50px;
height: 100vh;
overflow: hidden;
}
.login {
margin: 10% auto;
width: 300px;
}
.login-screen {
background-color: #FFF;
padding: 20px;
border-radius: 5px
}

.app-title {
text-align: center;
color: #777;
}

.login-form {
text-align: center;
}
.control-group {
margin-bottom: 10px;
}

input {
text-align: center;
background-color: #ECF0F1;
border: 2px solid transparent;
border-radius: 3px;
font-size: 16px;
font-weight: 200;
padding: 10px 0;
width: 250px;
transition: border .5s;
}

input:focus {
border: 2px solid #3498DB;
box-shadow: none;
}

.btn {
  border: 2px solid transparent;
  background: #3498DB;
  color: #ffffff;
  font-size: 16px;
  line-height: 25px;
  padding: 10px 0;
  text-decoration: none;
  text-shadow: none;
  border-radius: 3px;
  box-shadow: none;
  transition: 0.25s;
  display: block;
  width: 250px;
  margin: 0 auto;
}

.btn:hover {
  background-color: #2980B9;
}

.login-link {
  font-size: 12px;
  color: #444;
  display: block;
	margin-top: 12px;
}
.nav{
    position: absolute;
}
    </style>
  </head>
  <body>
    <input id="toggle" type="checkbox">
    <label class="toggle-container" for="toggle">
      <span class="button button-toggle"></span>
    </label>
    <nav class="nav">
      <a class="nav-item" href="http://amrita.edu">amirta.edu</a>
      <a class="nav-item" href="index.html">Map</a>
      <a class="nav-item" href="news.php">News</a>
      <a class="nav-item" href="https://www.amritapuri.org/">amritapuri.net</a>
      <a class="nav-item" href="https://www.facebook.com/MataAmritanandamayi">Facebook</a>
      <a class="nav-item" href="https://twitter.com/Amritanandamayi">Twitter</a>
      <a class="nav-item" href="https://www.instagram.com/Amritanandamayi/">Instagram</a>
      <a class="nav-item" href="https://www.youtube.com/user/amma">Youtube</a>
    </nav>
	<div class="login">
		<div class="login-screen">
			<div class="app-title">
				<h1>Login</h1>
			</div>
            <form method="post" action="process.php">
			<div class="login-form">
				<div class="control-group">
				<input type="text" class="login-field" value="" placeholder="username" id="login-name" required="true" name="uname">
				<label class="login-field-icon fui-user" for="login-name"></label>
				</div>

				<div class="control-group">
				<input type="password" class="login-field" value="" placeholder="password" id="login-pass" required="true" name="pass">
				<label class="login-field-icon fui-lock" for="login-pass"></label>
				</div>
				<?php
				    if($_GET["user"]){
				        echo '<div style="color: red; margin: 10px 0 10px 0;">Username or Password is Invalid</div>';
				    }
				?>
				<input type="submit" class="btn btn-primary btn-large btn-block" value="login">
			</div>
			</form>
		</div>
	</div>
</body>
</html>