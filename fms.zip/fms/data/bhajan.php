<style>
    table{
        width: 100%;
        text-align: center;
        background: white;
    }
    table, td{
        border: 1px solid black;
        border-collapse: collapse;
    }
</style>
<?php
$dbServerName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "fmsevents";

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = mysqli_query($conn, "SELECT event, time FROM Bhajan ORDER BY time ASC");

if ($result->num_rows > 0) {
    echo "<table><tr><th>Event</th><th>Time</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td class=\"event\">".$row["event"]."</td><td class=\"time\">".$row["time"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
mysqli_close($conn);
?>
<script>
    var d = new Date();
    var h = d.getHours();
    var t = document.getElementsByClassName("time");
    var e = document.getElementsByClassName("event");
    var f = 0;
    for(var i = 0; i < t.length; i++){
            if(t[i] == null){ break;}
            var m = t[i].innerHTML.substring(3,5);
            var c = parseInt(t[i].innerHTML);
        if(c <= h){
            t[i].style.color = "grey";
            e[i].style.color = "grey";
        } else if(f > 0){
            
        } else{
            t[i-1].style.fontWeight = "bold";
            e[i-1].style.fontWeight = "bold";
            t[i-1].style.color = "black";
            e[i-1].style.color = "black";
            f = 1;
        }
        if(c > 12){
            c -= 12;
            t[i].innerHTML = c+":"+m+" PM";
        }else{
            t[i].innerHTML = c+":"+m+" AM";
        }
    }
    if(f == 0){
        t[t.length-1].style.fontWeight = "bold";
        e[e.length-1].style.fontWeight = "bold";
        t[t.length-1].style.color = "black";
        e[e.length-1].style.color = "black";
        f = 1;
    }
</script>