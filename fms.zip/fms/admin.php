<?php session_start();?>
<?php
    if(isset($_SESSION["uname"])){
    } else {
        header("Location:login.php?user=notValid");
    }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset='utf-8' />
    <title>FMS</title>
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.css' rel='stylesheet' />
    <link href='css/style.css' rel='stylesheet' />
    <style>
        body {
            font-family: Arial;
            background-color: lightsteelblue;
            padding: 50px;
            overflow: hidden;
            overflow: scroll;
        }
        .content{
            border-radius: 5px;
            width: 100%;
            min-height: 90vh;
            background: white;
        }
        .nav{
            position: absolute;
        }
        .select{
            transform: translate(-50%, 0%);
            margin: 0px 0 10px 50%;
            display: inline-block;
        }
        table{
            margin: 50px 0 0 50%;
            padding-bottom: 50px;
            transform: translate(-50%, 0%);
        }
        table .event{
            width: 500px;
        }
        table .time{
            width: 100px;
        }
        table input{
            padding: 3px;
            margin: 3px;
        }
        .logout{
            display:block;
            position:absolute;
            right: 60px;
            top: 60px;
            background: white;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid gainsboro;
            
        }
        button, input[type="submit"]{
            background: white;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid gainsboro;
        }
        button:hover, input[type="submit"]:hover{
            background: gainsboro;
        }
        button:active, input[type="submit"]:active{
            background: grey;
        }
    </style>
  </head>
  <body>
    <input id="toggle" type="checkbox">
    <label class="toggle-container" for="toggle">
      <span class="button button-toggle"></span>
    </label>
    <nav class="nav">
      <a class="nav-item" href="http://amrita.edu">amirta.edu</a>
      <a class="nav-item" href="index.html">Map</a>
      <a class="nav-item" href="news.php">News</a>
      <a class="nav-item" href="https://www.amritapuri.org/">amritapuri.net</a>
      <a class="nav-item" href="https://www.facebook.com/MataAmritanandamayi">Facebook</a>
      <a class="nav-item" href="https://twitter.com/Amritanandamayi">Twitter</a>
      <a class="nav-item" href="https://www.instagram.com/Amritanandamayi/">Instagram</a>
      <a class="nav-item" href="https://www.youtube.com/user/amma">Youtube</a>
    </nav>
    <a href="logout.php"><button class="logout">Logout</button></a>
    <div class="content"><br>
        <form class="select"method="get" action="admin.php">
            <select name="db" value="biotech" id="select">
                <option value="Acharya">Acharya Hall</option>
                <option value="Amriteswari">Amriteswari Hall</option>
                <option value="Bhajan">Bhajan Hall</option>
                <option value="biotech">Biotech</option>
                <option value="campus">Engineering Campus</option>
                <option value="gate">Amrita Gate</option>
                <option value="grounds">Sports Grounds</option>
                <option value="stadium">Stadium</option>
                <option value="NEWS">News</option>
            </select>
            <input type="submit">
        </form>
        <script type="text/javascript">
            var db = "<?= $_GET['db']; ?>";
            if (db != ''){
                var sel = document.getElementById('select');
                var opts = sel.options;
                for (var opt, j = 0; opt = opts[j]; j++) {
                    if (opt.value == db) {
                         sel.selectedIndex = j;
                        break;
                    }
                }
            }
        </script>
        <?php
            if($_GET["update"]){
                echo "<p style=\"display: inline-block; color: green; margin: 0 0 0 50%; transform: translate(-50%, 0%);\">Updated ".$_GET["update"]."</p>";
            }
        ?>
        <?php
            if($_GET["db"]){
                $dbServerName = "localhost";
                $dbUsername = "root";
                $dbPassword = "";
                $dbName = "fmsevents";
                
                $db = $_GET["db"];
                // create connection
                $conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);
                
                // check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                if($db == "NEWS"){
                    echo "<table><tr><th>Title</th><th>Time</th><th>Description</th><th> </th></tr>";
                    echo "<tr><td><form method=\"post\" action=\"addnews.php\"><input class=\"title\" type=\"text\" name=\"title\"></td><td><input class=\"time\" type=\"text\" name=\"time\"></td><td><input class=\"event\" type=\"text\" name=\"desc\"></td><td><input type=\"submit\" value=\"Add\"></form></td></tr>";
                    echo "</table>";
                    mysqli_close($conn);
                } else{
                    $result = mysqli_query($conn, "SELECT event, time FROM $db ORDER BY time ASC");
                    
                    if ($result->num_rows > 0) {
                        echo "<table><tr><th>Event</th><th>Time</th><th></th><th></th></tr>";
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr><td><form method=\"post\" action=\"update.php\"><input type=\"hidden\" name=\"event0\" value=\"".$row["event"]."\"><input type=\"hidden\" name=\"time0\" value=\"".$row["time"]."\"><input type=\"hidden\" name=\"db\" value=\"$db\"><input class=\"event\" type=\"text\" name=\"event\" value=\"".$row["event"]."\"></td><td><input class=\"time\" type=\"text\" name=\"time\" value=\"".$row["time"]."\"></td><td><input type=\"submit\" value=\"Update\"></form></td><td><a href=\"delete.php?db=$db&event=".$row["event"]."&time=".$row["time"]."\"><button>Delete</button></a></td></tr>";
                        }
                    } else {
                        echo "<table><tr><th>Event</th><th>Time</th><th></th><th></th></tr>";
                    }
                    echo "<tr><td><form method=\"post\" action=\"add.php\"><input type=\"hidden\" name=\"db\" value=\"$db\"><input class=\"event\" type=\"text\" name=\"event\"></td><td><input class=\"time\" type=\"text\" name=\"time\"></td><td><input type=\"submit\" value=\"Add\"></form></td></tr>";
                    echo "</table>";
                    mysqli_close($conn);
                }
            }
        ?>
    </div>
  </body>
</html>